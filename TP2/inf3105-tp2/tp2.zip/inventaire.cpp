/*
  INF3105 - Structures de données et algorithmes
  UQAM / Département d'informatique
  Automne 2019
  
  Squelette de départ. Vous pouvez modifier ce fichier à votre guise.
  Vous n'êtes pas oubligés de l'utiliser.
*/

#include "inventaire.h"

ListeIngredients& ListeIngredients::operator+=(const ListeIngredients& autre)
{
    // À compléter.
    return *this;
}

ListeIngredients& ListeIngredients::operator*=(int facteur)
{
    // À compléter.
    return *this;
}
 
std::istream& operator >> (std::istream& is, ListeIngredients& liste)
{
    // À compléter.
    // Vider liste.
    
    std::string chaine;
    is >> chaine;
    while(is && chaine!="---"){
        int quantite;
        is >> quantite;
        // À compléter.
        is >> chaine;
    }
    return is;
}

Inventaire& Inventaire::operator+=(const Inventaire& autre)
{
    // À compléter.
    return *this;
}

Inventaire& Inventaire::operator-=(const ListeIngredients& liste)
{
    // À compléter.
    return *this;
}

std::istream& operator >> (std::istream& is, Inventaire& inventaire)
{
    // À compléter.
    // Vider inventaire
    std::string chaine;
    is >> chaine;
    while(is && chaine!="---"){
        int quantite;
        Date expiration;
        is >> quantite >> expiration;
        // À compléter.
        is >> chaine;
    }
    return is;
}

