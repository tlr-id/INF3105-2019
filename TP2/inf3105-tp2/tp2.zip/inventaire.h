/*
  INF3105 - Structures de données et algorithmes
  UQAM / Département d'informatique
  Automne 2019
  
  Squelette de départ. Vous pouvez modifier ce fichier à votre guise.
  Vous n'êtes pas oubligés de l'utiliser.
*/

#if !defined(_INVENTAIRE__H_)
#define _INVENTAIRE__H_

#include <iostream>
#include "date.h"

class ListeIngredients{
  public:
    ListeIngredients& operator+=(const ListeIngredients& liste);
    ListeIngredients& operator*=(int quantite);
   
  private:
  
  friend std::istream& operator >> (std::istream&, ListeIngredients&);
  friend class Inventaire;
};

class Inventaire{
  public:
    
    Inventaire& operator+=(const Inventaire&);
    Inventaire& operator-=(const ListeIngredients&);
    
  private:

  friend std::istream& operator >> (std::istream&, Inventaire&);
};

#endif

