/*
  INF3105 - Structures de données et algorithmes
  UQAM / Département d'informatique
  Automne 2019
  
  Squelette de départ. Vous pouvez modifier ce fichier à votre guise.
  Vous n'êtes pas oubligés de l'utiliser.
*/

#include <fstream>
#include "inventaire.h"

int tp2(std::istream& entree){
    // À Compléter:
    // - Déclaration du dictionnaire de recettes.
    // ArbreMap<std::string, ListeIngredients> recettes;
    
    Inventaire inventaire;
    int nocommande = 0;
    Date date;
    
    while(entree){
         std::string commande;
         entree >> commande;
         if(!entree) break;
         
         if(commande=="recette"){
             std::string nomrecette;
             entree >> nomrecette;
             ListeIngredients ingredients;
             entree >> ingredients;
             // À compléter...
         }
         else if(commande=="reception"){
             // À vérifier selon votre implémentation.
             Date date_reception;
             entree >> date_reception;
             if(date_reception <= date)
                 std::cout << "Attention : ce programme supporte uniquement un ordre chronologique (voir section 3.6 / hypothèse 3)!" << std::endl;
             date = date_reception;
             Inventaire inventairerecu;
             entree >> inventairerecu;
             inventaire += inventairerecu;
         }
         else if(commande=="reservation"){
             // À compléter...
             Date date_preparation;
             entree >> date_preparation;
             if(date_preparation <= date)
                 std::cout << "Attention : ce programme supporte uniquement un ordre chronologique (voir section 3.6 / hypothèse 3)!" << std::endl;
             date = date_preparation;
             
             std::string nomrecette;
             entree >> nomrecette;
             while(entree && nomrecette!="---"){
                 int quantite=0;
                 entree >> quantite;
                 // À compléter...
                 entree >> nomrecette;
             }
             // À compléter...
             std::cout << nocommande << " : Echec" << std::endl;
             nocommande++;
         }else{
             std::cout << "Commande '" << commande << "' inconnue!" << std::endl;
             return 2;
         }
    }
         
    return 0;
}

int main(int argc, const char** argv)
{
    // Gestion de l'entrée :
    //  - lecture dans un fichier si un nom est spécifié.
    //  - sinon, lecture dans std::cin
    if(argc>1){
         std::ifstream entree_fichier(argv[1]);
         if(entree_fichier.fail()){
             std::cerr << "Erreur d'ouverture du fichier '" << argv[1] << "'" << std::endl;
             return 1;
         }
         return tp2(entree_fichier);
    }else
         return tp2(std::cin);

}

